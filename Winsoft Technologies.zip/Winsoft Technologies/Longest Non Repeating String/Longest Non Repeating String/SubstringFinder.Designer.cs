﻿namespace Longest_Non_Repeating_String
{
    partial class SubstringFinder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SubstringFinder));
            this.header = new System.Windows.Forms.Panel();
            this.time = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelTime = new System.Windows.Forms.Label();
            this.substringIconBox = new System.Windows.Forms.PictureBox();
            this.date = new System.Windows.Forms.Label();
            this.closeBtnBox = new System.Windows.Forms.PictureBox();
            this.labelDate = new System.Windows.Forms.Label();
            this.heading = new System.Windows.Forms.Label();
            this.layout = new System.Windows.Forms.Panel();
            this.stringDetailsBox = new System.Windows.Forms.GroupBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.line1 = new System.Windows.Forms.PictureBox();
            this.Input = new System.Windows.Forms.Label();
            this.btnResult = new System.Windows.Forms.Button();
            this.Output = new System.Windows.Forms.Label();
            this.txt_string = new System.Windows.Forms.TextBox();
            this.footer = new System.Windows.Forms.Panel();
            this.Winsoft = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.header.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.substringIconBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBtnBox)).BeginInit();
            this.layout.SuspendLayout();
            this.stringDetailsBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.line1)).BeginInit();
            this.footer.SuspendLayout();
            this.SuspendLayout();
            // 
            // header
            // 
            this.header.BackColor = System.Drawing.SystemColors.Desktop;
            this.header.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.header.Controls.Add(this.time);
            this.header.Controls.Add(this.pictureBox1);
            this.header.Controls.Add(this.labelTime);
            this.header.Controls.Add(this.substringIconBox);
            this.header.Controls.Add(this.date);
            this.header.Controls.Add(this.closeBtnBox);
            this.header.Controls.Add(this.labelDate);
            this.header.Controls.Add(this.heading);
            this.header.Location = new System.Drawing.Point(0, 0);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(1370, 84);
            this.header.TabIndex = 0;
            // 
            // time
            // 
            this.time.AutoSize = true;
            this.time.BackColor = System.Drawing.Color.Transparent;
            this.time.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time.ForeColor = System.Drawing.Color.White;
            this.time.Location = new System.Drawing.Point(82, 44);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(104, 18);
            this.time.TabIndex = 34;
            this.time.Text = "User Name";
            this.time.MouseLeave += new System.EventHandler(this.time_MouseLeave);
            this.time.MouseHover += new System.EventHandler(this.time_MouseHover);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(953, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(124, 75);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // labelTime
            // 
            this.labelTime.AutoSize = true;
            this.labelTime.BackColor = System.Drawing.Color.Transparent;
            this.labelTime.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTime.ForeColor = System.Drawing.Color.White;
            this.labelTime.Location = new System.Drawing.Point(10, 44);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(58, 18);
            this.labelTime.TabIndex = 33;
            this.labelTime.Text = "Time :";
            this.labelTime.MouseLeave += new System.EventHandler(this.labelTime_MouseLeave);
            this.labelTime.MouseHover += new System.EventHandler(this.labelTime_MouseHover);
            // 
            // substringIconBox
            // 
            this.substringIconBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("substringIconBox.BackgroundImage")));
            this.substringIconBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.substringIconBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.substringIconBox.Location = new System.Drawing.Point(322, 3);
            this.substringIconBox.Name = "substringIconBox";
            this.substringIconBox.Size = new System.Drawing.Size(124, 75);
            this.substringIconBox.TabIndex = 1;
            this.substringIconBox.TabStop = false;
            // 
            // date
            // 
            this.date.AutoSize = true;
            this.date.BackColor = System.Drawing.Color.Transparent;
            this.date.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date.ForeColor = System.Drawing.Color.White;
            this.date.Location = new System.Drawing.Point(82, 17);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(104, 18);
            this.date.TabIndex = 32;
            this.date.Text = "User Name";
            this.date.MouseLeave += new System.EventHandler(this.date_MouseLeave);
            this.date.MouseHover += new System.EventHandler(this.date_MouseHover);
            // 
            // closeBtnBox
            // 
            this.closeBtnBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("closeBtnBox.BackgroundImage")));
            this.closeBtnBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.closeBtnBox.Location = new System.Drawing.Point(1326, -2);
            this.closeBtnBox.Name = "closeBtnBox";
            this.closeBtnBox.Size = new System.Drawing.Size(41, 44);
            this.closeBtnBox.TabIndex = 5;
            this.closeBtnBox.TabStop = false;
            this.closeBtnBox.Click += new System.EventHandler(this.closeBtnBox_Click);
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.BackColor = System.Drawing.Color.Transparent;
            this.labelDate.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDate.ForeColor = System.Drawing.Color.White;
            this.labelDate.Location = new System.Drawing.Point(10, 17);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(63, 18);
            this.labelDate.TabIndex = 31;
            this.labelDate.Text = "Date :";
            this.labelDate.MouseLeave += new System.EventHandler(this.labelDate_MouseLeave);
            this.labelDate.MouseHover += new System.EventHandler(this.labelDate_MouseHover);
            // 
            // heading
            // 
            this.heading.AutoSize = true;
            this.heading.BackColor = System.Drawing.Color.Transparent;
            this.heading.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.heading.Font = new System.Drawing.Font("Algerian", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.heading.ForeColor = System.Drawing.SystemColors.Control;
            this.heading.Location = new System.Drawing.Point(476, 29);
            this.heading.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.heading.Name = "heading";
            this.heading.Size = new System.Drawing.Size(447, 23);
            this.heading.TabIndex = 4;
            this.heading.Text = "Non Repeating Longest Substring Finder";
            this.heading.MouseLeave += new System.EventHandler(this.heading_MouseLeave);
            this.heading.MouseHover += new System.EventHandler(this.heading_MouseHover);
            this.heading.MouseMove += new System.Windows.Forms.MouseEventHandler(this.heading_MouseMove);
            // 
            // layout
            // 
            this.layout.BackColor = System.Drawing.Color.LightSkyBlue;
            this.layout.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.layout.Controls.Add(this.stringDetailsBox);
            this.layout.Controls.Add(this.footer);
            this.layout.Location = new System.Drawing.Point(0, 83);
            this.layout.Name = "layout";
            this.layout.Size = new System.Drawing.Size(1370, 674);
            this.layout.TabIndex = 1;
            // 
            // stringDetailsBox
            // 
            this.stringDetailsBox.Controls.Add(this.btnClear);
            this.stringDetailsBox.Controls.Add(this.pictureBox2);
            this.stringDetailsBox.Controls.Add(this.pictureBox3);
            this.stringDetailsBox.Controls.Add(this.line1);
            this.stringDetailsBox.Controls.Add(this.Input);
            this.stringDetailsBox.Controls.Add(this.btnResult);
            this.stringDetailsBox.Controls.Add(this.Output);
            this.stringDetailsBox.Controls.Add(this.txt_string);
            this.stringDetailsBox.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.stringDetailsBox.ForeColor = System.Drawing.Color.Crimson;
            this.stringDetailsBox.Location = new System.Drawing.Point(210, 168);
            this.stringDetailsBox.Name = "stringDetailsBox";
            this.stringDetailsBox.Size = new System.Drawing.Size(901, 219);
            this.stringDetailsBox.TabIndex = 2;
            this.stringDetailsBox.TabStop = false;
            this.stringDetailsBox.Text = "Input String Data : English Letters, Digits, Symbols, Spaces";
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(481, 172);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(111, 29);
            this.btnClear.TabIndex = 14;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            this.btnClear.MouseLeave += new System.EventHandler(this.btnClear_MouseLeave);
            this.btnClear.MouseHover += new System.EventHandler(this.btnClear_MouseHover);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.Info;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Location = new System.Drawing.Point(2, 148);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(896, 10);
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.Info;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox3.Location = new System.Drawing.Point(3, 90);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(896, 10);
            this.pictureBox3.TabIndex = 11;
            this.pictureBox3.TabStop = false;
            // 
            // line1
            // 
            this.line1.BackColor = System.Drawing.Color.Transparent;
            this.line1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.line1.Location = new System.Drawing.Point(11, 32);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(568, 4);
            this.line1.TabIndex = 10;
            this.line1.TabStop = false;
            // 
            // Input
            // 
            this.Input.AutoSize = true;
            this.Input.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Input.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Input.Location = new System.Drawing.Point(69, 50);
            this.Input.Name = "Input";
            this.Input.Size = new System.Drawing.Size(107, 21);
            this.Input.TabIndex = 7;
            this.Input.Text = "Enter String : ";
            this.Input.MouseLeave += new System.EventHandler(this.Input_MouseLeave);
            this.Input.MouseHover += new System.EventHandler(this.Input_MouseHover);
            // 
            // btnResult
            // 
            this.btnResult.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResult.Location = new System.Drawing.Point(333, 172);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(111, 29);
            this.btnResult.TabIndex = 6;
            this.btnResult.Text = "Result";
            this.btnResult.UseVisualStyleBackColor = true;
            this.btnResult.Click += new System.EventHandler(this.btnResult_Click);
            this.btnResult.MouseLeave += new System.EventHandler(this.btnResult_MouseLeave);
            this.btnResult.MouseHover += new System.EventHandler(this.btnResult_MouseHover);
            // 
            // Output
            // 
            this.Output.AutoSize = true;
            this.Output.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Output.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Output.Location = new System.Drawing.Point(69, 117);
            this.Output.Name = "Output";
            this.Output.Size = new System.Drawing.Size(76, 21);
            this.Output.TabIndex = 8;
            this.Output.Text = "Output : ";
            this.Output.Visible = false;
            // 
            // txt_string
            // 
            this.txt_string.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_string.Location = new System.Drawing.Point(202, 48);
            this.txt_string.Name = "txt_string";
            this.txt_string.Size = new System.Drawing.Size(665, 26);
            this.txt_string.TabIndex = 5;
            this.txt_string.TextChanged += new System.EventHandler(this.txt_string_TextChanged);
            // 
            // footer
            // 
            this.footer.BackColor = System.Drawing.SystemColors.Desktop;
            this.footer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.footer.Controls.Add(this.Winsoft);
            this.footer.Location = new System.Drawing.Point(-1, 595);
            this.footer.Name = "footer";
            this.footer.Size = new System.Drawing.Size(1369, 70);
            this.footer.TabIndex = 0;
            // 
            // Winsoft
            // 
            this.Winsoft.AutoSize = true;
            this.Winsoft.BackColor = System.Drawing.Color.Transparent;
            this.Winsoft.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Winsoft.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Winsoft.ForeColor = System.Drawing.SystemColors.Control;
            this.Winsoft.Location = new System.Drawing.Point(519, 17);
            this.Winsoft.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Winsoft.Name = "Winsoft";
            this.Winsoft.Size = new System.Drawing.Size(267, 26);
            this.Winsoft.TabIndex = 35;
            this.Winsoft.Text = "Winsoft Technologies";
            this.Winsoft.MouseLeave += new System.EventHandler(this.Winsoft_MouseLeave);
            this.Winsoft.MouseHover += new System.EventHandler(this.Winsoft_MouseHover);
            // 
            // SubstringFinder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.layout);
            this.Controls.Add(this.header);
            this.Name = "SubstringFinder";
            this.Text = "SubstringFinder";
            this.Load += new System.EventHandler(this.SubstringFinder_Load);
            this.header.ResumeLayout(false);
            this.header.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.substringIconBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBtnBox)).EndInit();
            this.layout.ResumeLayout(false);
            this.stringDetailsBox.ResumeLayout(false);
            this.stringDetailsBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.line1)).EndInit();
            this.footer.ResumeLayout(false);
            this.footer.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel header;
        private System.Windows.Forms.PictureBox closeBtnBox;
        private System.Windows.Forms.Label heading;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox substringIconBox;
        private System.Windows.Forms.Panel layout;
        private System.Windows.Forms.Panel footer;
        private System.Windows.Forms.Label Output;
        private System.Windows.Forms.Button btnResult;
        private System.Windows.Forms.GroupBox stringDetailsBox;
        private System.Windows.Forms.Label Input;
        private System.Windows.Forms.TextBox txt_string;
        private System.Windows.Forms.PictureBox line1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label time;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Label date;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label Winsoft;
        private System.Windows.Forms.Button btnClear;
    }
}
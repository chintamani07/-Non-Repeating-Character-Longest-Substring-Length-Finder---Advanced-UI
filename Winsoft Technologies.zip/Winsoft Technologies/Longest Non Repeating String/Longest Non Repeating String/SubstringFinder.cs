﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Longest_Non_Repeating_String
{
    public partial class SubstringFinder : Form
    {
        public SubstringFinder()
        {
            InitializeComponent();
        }

        private void SubstringFinder_Load(object sender, EventArgs e)
        {
            timer1.Start();
            date.Text = DateTime.Now.ToString("dd/MM/yyyy,( dddd )");
            time.Text = DateTime.Now.ToString("hh:mm:ss");
        }
        private int LengthOfLongestSubstring(string s)
        {
            int maxLength = 0;
            int[] charIndex = new int[256];
            int i = 0;

            for (int j = 0; j < s.Length; j++)
            {
                i = Math.Max(charIndex[s[j]], i);
                maxLength = Math.Max(maxLength, j - i + 1);
                charIndex[s[j]] = j + 1;
            }

            return maxLength;
        }

        private int LengthOfLongestNullSubstring(string s)
        {
            int minLength = 0;
            int[] charIndex = new int[256];
            int i = 0;

            for (int j = 0; j < s.Length; j++)
            {
                i = Math.Max(charIndex[s[j]], i);
                minLength = Math.Max(minLength, j - i + 1);
                charIndex[s[j]] = j + 1;
            }

            return minLength;
        }

        private string LongestSubstringWithoutRepeatingCharacters(string s)
        {
            int maxLength = 0;
            int[] charIndex = new int[256];
            int start = 0;
            int end = 0;

            for (int j = 0; j < s.Length; j++)
            {
                start = Math.Max(charIndex[s[j]], start);
                if (j - start + 1 > maxLength)
                {
                    maxLength = j - start + 1;
                    end = j;
                }
                charIndex[s[j]] = j + 1;
            }

            return s.Substring(end - maxLength + 1, maxLength);
        }

        private string LongestSubstringWithNullInput(string s)
        {
            int minLength = 1;
            int[] charIndex = new int[256];
            int start = 0;
            int end = 0;

            for (int j = 0; j < s.Length; j++)
            {
                start = Math.Max(charIndex[s[j]], start);
                if (j - start + 1 > minLength)
                {
                    minLength = j - start + 1;
                    end = j;
                }
                charIndex[s[j]] = j + 1;
            }

            return s.Substring(end - minLength + 1, minLength);
        }

        private void btnResult_Click(object sender, EventArgs e)
        {
                Output.Visible = true;

                //string input = textBox1.Text;
                //int maxLength = LengthOfLongestSubstring(input);
                //label2.Text = "Length of longest substring without repeating characters: " + maxLength;

                string input = txt_string.Text;
                if (input.Length > 5 * 104)
                {
                    MessageBox.Show("Input string length exceeds the maximum allowed length.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else if (input.Length == 0)
                {
                    try
                    {
                        int minLength = LengthOfLongestNullSubstring(input);
                        string longestNullSubstring = LongestSubstringWithNullInput(input);
                    }
                    catch
                    {
                        DialogResult result = MessageBox.Show("Input String Can Not Be NULL!!", "NULL Value Exception", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                        return;
                    }
                }
                else
                {

                    int maxLength = LengthOfLongestSubstring(input);
                    string longestSubstring = LongestSubstringWithoutRepeatingCharacters(input);
                    Output.Text = string.Format("Longest substring without repeating characters: '{0}', Length: {1}", longestSubstring, maxLength);
                }
            }

        private void txt_string_TextChanged(object sender, EventArgs e)
        {
            Output.Visible = false;
        }

        private void closeBtnBox_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        private void labelDate_MouseHover(object sender, EventArgs e)
        {
            labelDate.ForeColor = Color.IndianRed;
        }

        private void labelDate_MouseLeave(object sender, EventArgs e)
        {
            labelDate.ForeColor = Color.White;
        }

        private void date_MouseHover(object sender, EventArgs e)
        {
            date.ForeColor = Color.IndianRed;
        }

        private void date_MouseLeave(object sender, EventArgs e)
        {
            date.ForeColor = Color.White;
        }
  
        private void labelTime_MouseHover(object sender, EventArgs e)
        {
            labelTime.ForeColor = Color.White;
        }

        private void labelTime_MouseLeave(object sender, EventArgs e)
        {
            labelTime.ForeColor = Color.White;
        }

        private void time_MouseHover(object sender, EventArgs e)
        {
            time.ForeColor = Color.IndianRed;
        }

        private void time_MouseLeave(object sender, EventArgs e)
        {
            time.ForeColor= Color.White;
        }

        private void heading_MouseMove(object sender, MouseEventArgs e)
        {
            if (heading.ForeColor == Color.IndianRed)
            {
                DialogResult res = MessageBox.Show("Welcome To Non Repeating Largest Substring Finder", "Information", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (res == DialogResult.No)
                {
                    this.Close();
                }
            }
        }

        private void heading_MouseHover(object sender, EventArgs e)
        {
            heading.ForeColor = Color.IndianRed;
        }

        private void heading_MouseLeave(object sender, EventArgs e)
        {
            heading.ForeColor= Color.White;
        }

        private void Input_MouseHover(object sender, EventArgs e)
        {
            Input.ForeColor = Color.White;
        }

        private void Input_MouseLeave(object sender, EventArgs e)
        {
            Input.ForeColor= Color.Black;
        }

        private void Output_MouseHover(object sender, EventArgs e)
        {
            Output.ForeColor = Color.White;
        }

        private void Output_MouseLeave(object sender, EventArgs e)
        {
            Output.ForeColor= Color.Black;
        }

        private void btnResult_MouseHover(object sender, EventArgs e)
        {
            btnResult.ForeColor = Color.Black;
        }

        private void btnResult_MouseLeave(object sender, EventArgs e)
        {
            btnResult.ForeColor= Color.IndianRed;
        }

        private void btnClear_MouseHover(object sender, EventArgs e)
        {
            btnClear.ForeColor = Color.Black;
        }

        private void btnClear_MouseLeave(object sender, EventArgs e)
        {
            btnClear.ForeColor= Color.IndianRed;
        }

        private void Winsoft_MouseHover(object sender, EventArgs e)
        {
            Winsoft.ForeColor = Color.PaleGoldenrod;
        }

        private void Winsoft_MouseLeave(object sender, EventArgs e)
        {
            Winsoft.ForeColor= Color.White;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txt_string.Text = "";
        }
    }
}
